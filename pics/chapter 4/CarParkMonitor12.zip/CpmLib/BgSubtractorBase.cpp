#include "BgSubtractorBase.h"

int BgSubtractorBase::instanceNr = 0;