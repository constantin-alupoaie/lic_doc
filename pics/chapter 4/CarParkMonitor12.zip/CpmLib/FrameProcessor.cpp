#include "FrameProcessor.h"

FrameProcessor::FrameProcessor( char* windowName )
{
}
