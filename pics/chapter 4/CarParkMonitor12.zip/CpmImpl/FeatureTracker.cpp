#include "FeatureTracker.h"


FeatureTracker::~FeatureTracker(void)
{
}
